"""
Services package for DocuIntel.
"""
