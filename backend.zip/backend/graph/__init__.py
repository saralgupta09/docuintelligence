"""
Graph package for DocuIntel.
"""
