"""
Ingestion package for DocuIntel.
"""
