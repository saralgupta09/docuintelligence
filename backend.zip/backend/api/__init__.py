"""
API package for DocuIntel.
"""
