"""
Backend package for DocuIntel.
"""
